//############################################################################
//##                                                                        ##
//##  Miles Sound System                                                    ##
//##                                                                        ##
//##  OGGAPI.CPP: ASI API module for Ogg Vorbis                             ##
//##                                                                        ##
//##  Version 1.00 of 8-Apr-98: Initial                                     ##
//##                                                                        ##
//##  Author: John Miles                                                    ##
//##                                                                        ##
//############################################################################
//##                                                                        ##
//##  Copyright (C) RAD Game Tools, Inc.                                    ##
//##                                                                        ##
//##  Contact RAD Game Tools at 425-893-4300 for technical support.         ##
//##                                                                        ##
//############################################################################

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "mss.h"
#include "imssapi.h"

#include "oggdec.h"

static S32 ASI_started = 0;

static C8 ASI_error_text[256];

//
// Table of destination (WDM) channel indexes for each source (AC3) channel,
// for one to six-channel formats
//
// This converts Vorbis's AC3-style channel order to the standard 
// WAVEFORMATEXTENSIBLE order used by MSS
//
// For >6-channel formats, channel order is application-defined, per
// Vorbis I spec
//

static const S32 AC3_to_WDM[6][6] = { { 0, 0, 0, 0, 0, 0 },     // mono
                                      { 0, 1, 0, 0, 0, 0 },     // stereo
                                      { 0, 2, 1, 0, 0, 0 },     // 1D surround 
                                      { 0, 1, 2, 3, 0, 0 },     // quadraphonic
                                      { 0, 2, 1, 3, 4, 0 },     // 5.0
                                      { 0, 2, 1, 4, 5, 3 } };   // 5.1

//
// Table of WAVEFORMATEXTENSIBLE;.dwChannelMask-equivalent channel masks corresponding
// to one to six-channel formats
//

static const S32 WDM_masks[6] = { (1 << MSS_SPEAKER_FRONT_LEFT),

                                  (1 << MSS_SPEAKER_FRONT_LEFT)    |
                                  (1 << MSS_SPEAKER_FRONT_RIGHT),

                                  (1 << MSS_SPEAKER_FRONT_LEFT)    |
                                  (1 << MSS_SPEAKER_FRONT_RIGHT)   |
                                  (1 << MSS_SPEAKER_BACK_CENTER),

                                  (1 << MSS_SPEAKER_FRONT_LEFT)    |
                                  (1 << MSS_SPEAKER_FRONT_RIGHT)   |
                                  (1 << MSS_SPEAKER_BACK_LEFT)     |
                                  (1 << MSS_SPEAKER_BACK_RIGHT),

                                  (1 << MSS_SPEAKER_FRONT_LEFT)    |
                                  (1 << MSS_SPEAKER_FRONT_CENTER)  |
                                  (1 << MSS_SPEAKER_FRONT_RIGHT)   |
                                  (1 << MSS_SPEAKER_BACK_LEFT)     |
                                  (1 << MSS_SPEAKER_BACK_RIGHT),

                                  (1 << MSS_SPEAKER_FRONT_LEFT)    |
                                  (1 << MSS_SPEAKER_FRONT_RIGHT)   |
                                  (1 << MSS_SPEAKER_FRONT_CENTER)  |
                                  (1 << MSS_SPEAKER_LOW_FREQUENCY) |
                                  (1 << MSS_SPEAKER_BACK_LEFT)     |
                                  (1 << MSS_SPEAKER_BACK_RIGHT) };
//
// Property tokens
//

enum PROPERTY
{
   //
   // Additional decoder props (beyond standard RIB PROVIDER_ properties)
   //

   IN_FTYPES,               // STRING supported input file types
   OUT_FTYPES,              // STRING supported output file types
   FRAME_SIZE,              // S32 worst-case frame buffer size

   //
   // Generic ASI stream props
   //

   INPUT_BIT_RATE,          // S32 input bit rate
   INPUT_SAMPLE_RATE,       // S32 sample rate of input data
   INPUT_BITS,              // S32 bit width per sample of input data
   INPUT_CHANNELS,          // S32 # of channels in input data

   OUTPUT_BIT_RATE,         // S32 output bit rate
   OUTPUT_SAMPLE_RATE,      // S32 output sample rate
   OUTPUT_BITS,             // S32 bit width per sample of output data
   OUTPUT_CHANNELS,         // S32 # of channels in output data
   OUTPUT_CHANNEL_MASK,     // U32 channel mask, compatible with WAVEFORMATEXTENSIBLE.dwChannelMask

   OUTPUT_RESERVOIR,        // S32 bytes decoded but not yet requested from ASI_stream_process
   POSITION,                // S32 bytes processed so far
   PERCENT_DONE,            // % percent done
   MIN_INPUT_BLOCK_SIZE,    // S32 minimum block size for input

   //
   // Codec-specific stream props
   //

   //
   // Stream properties
   //

   REQUESTED_RATE,          // S32 requested rate for output data
   REQUESTED_BITS,          // S32 requested bit width for output data
   REQUESTED_CHANS,         // S32 requested # of channels for output data
   STREAM_SEEK_POS          // S32 S->pos value after a stream seek (e.g., any change in HSAMPLE position other than normal incrementing during playback)
};

//############################################################################ 
//#                                                                          #
//# Memory handlers for libogg/libvorbis code base                           #
//#                                                                          #
//############################################################################

//
// We deliberately enter an infinite loop here if the Ogg Vorbis library 
// tries to perform any heap activity at background time; i.e., from within
// ASI_stream_process()
//
// The PS2 system library traps some, but not all, heap calls at interrupt time, 
// and we want to fail positively if the OGG_PAGE_MARGIN and INITIAL_VORBIS_BLOCK_ALLOC
// margin constants aren't sufficient to play a given file
//

void *_ogg_malloc (int size)
{
   while (AIL_background()) {};

   return AIL_mem_alloc_lock(size);
}

void *_ogg_calloc  (int nelem, int elsize)
{
   int size = nelem * elsize;

   void *ptr = _ogg_malloc(size);

   if (ptr != NULL)
      {
      AIL_memset(ptr, 0, size);
      }

   return ptr;
}

void  _ogg_free    (void *ptr)
{
   //
   // Background free()s are OK, since they're deferred by AIL_mem_free_lock()
   //

   AIL_mem_free_lock(ptr);
}

void *_ogg_realloc (void *ptr, int old_size, int new_size)
{
   void *dest = _ogg_malloc(new_size);

   int n = (old_size > new_size) ? new_size : old_size;

   if (ptr != NULL)
      {
      AIL_memcpy(dest, ptr, n);
      _ogg_free(ptr);
      }

   return dest;
}

//############################################################################
//#                                                                          #
//# Flush any buffered data from Ogg stream by requesting packets until      #
//# more data requested                                                      #
//#                                                                          #
//############################################################################

static void flush_stream(ASISTREAM FAR *STR)
{
   S32 result = -1;

   for(;;)
      {
#if 0
      F32 **pcm = NULL;
      S32   samples_avail;

      while ((samples_avail = vorbis_synthesis_pcmout(&STR->vd, &pcm)) > 0)
         {
         vorbis_synthesis_read(&STR->vd, samples_avail);
         }
#else
      vorbis_synthesis_restart(&STR->vd);    // better than above, since it's faster and clears the overlap data too...
#endif

      //
      // Assemble the next valid packet, or conclude that we need more data...
      //

      S32 res2;

      do
         {
         res2 = ogg_stream_packetout(&STR->os, &STR->op);
         }
      while (res2 < 0);

      if (res2 > 0)
         {
         if (vorbis_synthesis(&STR->vb, &STR->op) == 0)
            {
            vorbis_synthesis_blockin(&STR->vd, &STR->vb);
            }

         continue;
         }

      if (result == 0)
         {
         break;
         }

      //
      // Fetch/decode next page, if any
      //
      // Note that if we call Ogg to check for EOS here (after decoder_example.c), we'll never have
      // the chance to load any further data from a looping file or stream
      // 

      for(;;)
         {
         result = ogg_sync_pageout(&STR->oy, &STR->og);

         if (result > 0)            
            {       
            //
            // Break incoming page into decodable packets
            //

            if (ogg_stream_pagein(&STR->os, &STR->og) != 0)
               {
               //
               // Mismatched page or other corruption issue -- fetch another page and keep going
               //

               continue;
               }

            break;               // Valid data available, exit loop 
            }
         else if (result < 0)    
            {                    // Ignore corrupt/unknown data  
            continue;
            }
      
         break;
         }
      }

   STR->remaining_output_bytes = 0;
}

//############################################################################
//#                                                                          #
//# Retrieve a standard RIB provider property by index                       #
//#                                                                          #
//############################################################################

static S32 AILCALL PROVIDER_property(HPROPERTY index, void FAR * before_value, void const FAR * new_value, void FAR * after_value)
{
   switch (/* (PROPERTY) */ index)
      {
      case PROVIDER_NAME:
        if (before_value)
        {
          *(char FAR * FAR*)before_value = "MSS Ogg Vorbis Audio Decoder";
          return 1;
        }
        break;
        
      case PROVIDER_VERSION:
        if (before_value) 
        {
          *(S32 FAR*)before_value = 0x110;
          return 1;
        }
        break;

      case IN_FTYPES:
        if (before_value)
        {
          *(char FAR * FAR*)before_value =  "Ogg Vorbis audio files\0*.OGG\0";
          return 1;
        }
        break;
        
      case OUT_FTYPES:
        if (before_value)
        {
          *(char FAR * FAR*)before_value = "Raw PCM files\0*.RAW\0";
          return 1;
        }
        break;
        
      case FRAME_SIZE:
        if (before_value)
        {
          *(S32 FAR*)before_value = OGG_PAGE_SIZE;
          return 1;
        }
        break;

      default:
         break;
      }

   return 0;
}

//############################################################################
//#                                                                          #
//# Return ASI decoder error text                                            #
//#                                                                          #
//############################################################################

static C8 FAR *       AILCALL ASI_error       (void)
{
   if (ASI_error_text[0]==0)
      {
      return NULL;
      }

   return ASI_error_text;
}


//############################################################################
//#                                                                          #
//# Initialize ASI stream decoder                                            #
//#                                                                          #
//############################################################################

static ASIRESULT AILCALL ASI_startup     (void)
{
   if (ASI_started++)
      {
      strcpy(ASI_error_text,"Already started");
      return ASI_ALREADY_STARTED;
      }

   //
   // Init static properties
   //

   ASI_error_text[0] = 0;

   //
   // Init decoder globals
   //

   return ASI_NOERR;
}

//############################################################################
//#                                                                          #
//# Shut down ASI stream decoder                                             #
//#                                                                          #
//############################################################################

static ASIRESULT      AILCALL ASI_shutdown    (void)
{
   if (!ASI_started)
      {
      strcpy(ASI_error_text,"Not initialized");
      return ASI_NOT_INIT;
      }

   --ASI_started;

   //
   // Destroy codec globals
   //

   return ASI_NOERR;
}

//############################################################################
//#                                                                          #
//# Close stream, freeing handle and all internally-allocated resources      #
//#                                                                          #
//############################################################################

static ASIRESULT      AILCALL ASI_stream_close(ASISTREAM FAR *STR)
{
   ogg_stream_clear(&STR->os);
   /* ogg_page and ogg_packet structs always point to storage in
            libvorbis.  They're never freed or manipulated directly */

   vorbis_block_clear(&STR->vb);
   vorbis_dsp_clear(&STR->vd);
   vorbis_comment_clear(&STR->vc);
   vorbis_info_clear(&STR->vi);                         /* must be called last */

   /* OK, clean up the framer */
   ogg_sync_clear(&STR->oy);

   AIL_mem_free_lock(STR);
   return ASI_NOERR;
}


//############################################################################
//#                                                                          #
//# Open a stream, returning handle to stream                                #
//#                                                                          #
//############################################################################

static HASISTREAM   AILCALL ASI_stream_open (UINTa         user,  //)
                                             AILASIFETCHCB fetch_CB,
                                             U32           total_size)
{
   //
   // Allocate ASISTREAM descriptor
   //
   // Make sure it's paragraph aligned (even in DEBUGALLOC mode) for the benefit 
   // of any SIMD code...
   //

   ASISTREAM FAR *STR = (ASISTREAM FAR *) AIL_mem_alloc_lock((sizeof(ASISTREAM) + 15) & ~15);

   if (STR == NULL)
      {
      strcpy(ASI_error_text,"ASI_stream_open() failed -- out of memory");
      return 0;
      }

   AIL_memset(STR, 0, sizeof(ASISTREAM));

   STR->user       = user;
   STR->fetch_CB   = (VOIDFUNC*) fetch_CB;
   STR->total_size = total_size;

   //
   // Init props
   //

   STR->requested_rate = -1;
   STR->requested_bits = -1;
   STR->requested_chans = -1;

   //
   // Init Ogg decoder and grab some data at the head of the stream
   //
   // (We assume that total_size is unavailable from the file header, so the caller must supply it)
   //

   ogg_sync_init(&STR->oy);                                // Now we can read pages

   void *src = ogg_sync_buffer(&STR->oy, OGG_PAGE_SIZE);   // Submit a 4k block to libvorbis' Ogg layer  

   S32 offset = 0;

   S32 bytes = call_fetch_CB(STR,
                             STR->user,
                             src,
                             OGG_PAGE_SIZE,
                             0);
   offset += bytes;

   if (bytes == 0)
      {
      strcpy(ASI_error_text,"ASI_stream_open() failed -- truncated file");
      ASI_stream_close(STR);
      return 0;
      }

   ogg_sync_wrote(&STR->oy, bytes);

   //
   // Get the first page
   //
      
   if (ogg_sync_pageout(&STR->oy, &STR->og) != 1)
      {
      strcpy(ASI_error_text,"ASI_stream_open() failed -- invalid or truncated Ogg Vorbis file");
      ASI_stream_close(STR);
      return 0;
      }

   //
   // Get the serial number and use it to set up a logical stream
   //

   ogg_stream_init(&STR->os, ogg_page_serialno(&STR->og));

   //
   // Extract the initial header from the first page and verify that the
   // Ogg bitstream is in fact Vorbis data
   //

   vorbis_info_init   (&STR->vi);
   vorbis_comment_init(&STR->vc);

   if (ogg_stream_pagein(&STR->os, &STR->og) < 0)
      {
      strcpy(ASI_error_text,"Error reading first page of Ogg bitstream data (version mismatch?)");
      ASI_stream_close(STR);
      return 0;
      }

   if (ogg_stream_packetout(&STR->os, &STR->op) != 1)
      {
      strcpy(ASI_error_text, "Error reading initial header packet: no valid Vorbis page");
      ASI_stream_close(STR);
      return 0;
      }

   if (vorbis_synthesis_headerin(&STR->vi, &STR->vc, &STR->op) < 0)
      {
      strcpy(ASI_error_text, "Error: Ogg bitstream does not contain Vorbis audio data");
      ASI_stream_close(STR);
      return 0;
      }

   //
   // At this point, we're sure we're Vorbis.  We've set up the logical
   // (Ogg) bitstream decoder. 
   //
   // The next two packets in order are the comment and codebook headers.
   // They're likely large and may span multiple pages.  Thus we read
   // and submit data until we get our two packets, watching that no
   // pages are missing.  If a page is missing, error out; losing a
   // header page is the only place where missing data is fatal.
   //
   
   S32 i = 0;

   while (i < 2)
      {
      while (i < 2)     // This leetness brought to you by Xiph.org example
         {
         S32 result = ogg_sync_pageout(&STR->oy, &STR->og);

         if (result == 0)
            {
            break;      // Need more data 
            }

         if (result == 1)
            {
            ogg_stream_pagein(&STR->os, &STR->og);    
                                                      
            while (i < 2)
               {
               result = ogg_stream_packetout(&STR->os, &STR->op);

               if (result == 0)
                  {
                  break;
                  }

               if (result < 0)   
                  {              
                  strcpy(ASI_error_text, "Error: Corrupt Ogg secondary header");
                  ASI_stream_close(STR);
                  return 0;
                  }

               vorbis_synthesis_headerin(&STR->vi, &STR->vc, &STR->op);
               i++;
               }
            }
         }

      //
      // No harm in not checking before adding more data
      //

      void *src = ogg_sync_buffer(&STR->oy, OGG_PAGE_SIZE);

      bytes = call_fetch_CB(STR,
                            STR->user,
                            src,
                            OGG_PAGE_SIZE,
                           -1);
      offset += bytes;

      if ((bytes == 0) && (i < 2))
         {
         strcpy(ASI_error_text, "Error: EOF reached before finding all Vorbis headers");
         ASI_stream_close(STR);
         return 0;
         }

      ogg_sync_wrote(&STR->oy, bytes);
      }

   STR->nch                     = STR->vi.channels;
   STR->sample_rate             = STR->vi.rate;
   STR->bit_rate                = STR->vi.bitrate_nominal;  
   STR->bytes_per_sample        = STR->vi.channels * sizeof(S16);
   STR->remaining_output_bytes  = 0;

   if (!STR->bit_rate)
      {
      STR->bit_rate = 128000;    // Some Ogg streams may not specify their rate, but we have to report a valid rate, so make something up...
      }

   //
   // Initialize Vorbis packet->PCM decoder
   //

   vorbis_synthesis_init(&STR->vd, &STR->vi);   // central decode state
   vorbis_block_init(&STR->vd, &STR->vb);       // local state for most of the decode so multiple block decodes can proceed in parallel

   //
   // Set offset parameter to -1 for all subsequent data-fetch callbacks, to allow
   // application to perform continuous streaming without explicit seeks
   //
   // Current offset is specified relative to beginning of file (from the MSS application's 
   // standpoint, Ogg files don't have separate header/data portions)
   //
   // In practice, streams are generally rewound immediately after being opened, so the stream_process()
   // function may have to skip all of those header chunks again...
   //

   STR->seek_param     = -1;
   STR->current_offset = offset;

   return (HASISTREAM) STR;
}

//############################################################################
//#                                                                          #
//# Decode data from stream, returning # of bytes actually decoded           #
//#                                                                          #
//############################################################################

static S32 AILCALL ASI_stream_process (HASISTREAM  stream, //)
                                         void FAR   *buffer,
                                         S32         request_size)
{
   ASISTREAM FAR *STR = (ASISTREAM FAR *) stream;

   //
   // Set offset parameter to -1 for all subsequent frames, to allow
   // application to perform continuous streaming without explicit seeks
   //

   if (STR->seek_param != -1)
      {
      STR->current_offset = STR->seek_param;
      }

   S32 seek_offset = STR->seek_param;

   STR->seek_param = -1;

   //
   // Keep track of # of bytes originally requested
   //

   S32 original_request = request_size;
   S32 result = 0;

   //
   // Init buffer output offset
   //

   S32 write_cursor = 0;

   //
   // If any data from last frame remains in Ogg internal buffer, copy it first
   //
   // Otherwise fetch and decode frame data until request size satisfied
   //

   U8 *dest = (U8 *) buffer;

   S32 EOS_reached = FALSE;

   while (request_size > 0)
      {
      //
      // **pcm is a multichannel float vector.  In stereo, for       
      // example, pcm[0] is left, and pcm[1] is right.  samples is   
      // the size of each channel.  Convert the float values         
      // (-1.<=range<=1.) to S16 PCM format and write it out
      //

      F32 **pcm = NULL;
      S32   samples_avail;

      STR->remaining_output_bytes = 0;

      while ((samples_avail = vorbis_synthesis_pcmout(&STR->vd, &pcm)) > 0)
         {
         S32 samples_needed = request_size / STR->bytes_per_sample;

         S32 samples_consumed = (samples_avail < samples_needed) ? samples_avail : samples_needed;

         if ((samples_needed == 0) || ((request_size % STR->bytes_per_sample) != 0))
            {
            MSSBreakPoint();  // (sanity check for multichannel calls; can be removed)
            }

         //
         // Remap channels from AC3 to WAVEFORMATEXTENSIBLE style, if the format
         // has <= 6 channels
         //

         for (S32 ch = 0; ch < STR->vi.channels; ch++)
            {
            S16 *d = ((S16 *) &dest[write_cursor]) +
                              ((STR->vi.channels > 6) ? ch : AC3_to_WDM[STR->vi.channels-1][ch]);

            for (S32 i=0; i < samples_consumed; i++)
               {
               F32 v = pcm[ch][i];
               S16 o;

                    if (v >=  1.0F) o =  32767;
               else if (v <= -1.0F) o = -32768;
               else                 o = (S16) (v * 32767.0F);

               STORE_LE_SWAP16(d,o);

               d += STR->vi.channels;
               }
            }

         S32 bytes = samples_consumed * STR->bytes_per_sample;

         write_cursor += bytes;
         request_size -= bytes;

         vorbis_synthesis_read(&STR->vd, samples_consumed);      // Tell Vorbis how many samples we actually consumed

         if (!request_size)
            {
            STR->remaining_output_bytes = (samples_avail - samples_consumed) * STR->bytes_per_sample;
            break;
            }
         }

      //
      // Exit from routine if request completely fulfilled by existing buffer
      // contents, or if no more data is available
      //

      if ((!request_size) || EOS_reached)
         {
         break;
         }

      //
      // Assemble the next valid packet, or conclude that we need more data...
      //

      do
         {
         result = ogg_stream_packetout(&STR->os, &STR->op);
         }
      while (result < 0);

      if (result > 0)
         {
         if (vorbis_synthesis(&STR->vb, &STR->op) == 0)
            {
            vorbis_synthesis_blockin(&STR->vd, &STR->vb);
            }

         continue;
         }

      //
      // Fetch/decode next page, if any
      //
      // Note that if we call Ogg to check for EOS here (after decoder_example.c), we'll never have
      // the chance to load any further data from a looping file or stream
      // 

      while (!EOS_reached)      // Fetch loop terminates at EOS or when next page is available
         {
         result = ogg_sync_pageout(&STR->oy, &STR->og);

         if (result > 0)            
            {       
            //
            // Break incoming page into decodable packets
            //

            if (ogg_stream_pagein(&STR->os, &STR->og) != 0)
               {
               //
               // Mismatched page or other corruption issue -- fetch another page and keep going
               //

               continue;
               }

            break;               // Valid data available, exit loop 
            }
         else if (result < 0)    
            {                    // Ignore corrupt/unknown data  
            continue;
            }
      
         //
         // Fetch more source data
         //

         void *src = ogg_sync_buffer(&STR->oy, OGG_PAGE_SIZE);

         S32 bytes = call_fetch_CB(STR,
                                   STR->user,
                                   src,
                                   OGG_PAGE_SIZE,
                                   seek_offset);
         seek_offset = -1;
         STR->current_offset += bytes;

         ogg_sync_wrote(&STR->oy, bytes);

         if (bytes == 0)
            {
            EOS_reached = TRUE;
            }
         }

      //
      // Flag EOS condition when the source stream fails to return any more data, not
      // when Ogg says the file's done
      //
      // Otherwise, looped files may terminate prematurely
      //

#if 0
      if (ogg_page_eos(&STR->og))
         {
         EOS_reached = TRUE;
         }
#endif
      }

   //
   // If source stream exhausted, pad with zeroes to end of buffer
   //

   if (request_size > 0)
      {
      AIL_memset(&dest[write_cursor],
                  0,
                  request_size);
      }

   //
   // Return # of bytes fetched from source stream
   //

   return original_request - request_size;
}

//############################################################################
//#                                                                          #
//# Restart stream decoding process at new offset                            #
//#                                                                          #
//# Positive offset: Same as -1 below, but value will be treated as new      #
//#     stream position for the next data-fetch callback and subsequent      #
//#     position property queries                                            #
//#                                                                          #
//# -1: Clear output filter and bit reservoir, and discard both              #
//#     input and output buffers without specifying a new offset.            #
//#     Used for performing explicit asynchronous seeks when the caller      #
//#     doesn't care about updating the ASI codec's position property        #
//#                                                                          #
//# -2: Clear bit reservoir and input buffer, but do not discard accumulated #
//#     output data, filter state, or overlap contents.  Used for looping    #
//#                                                                          #
//############################################################################

static ASIRESULT AILCALL ASI_stream_seek (HASISTREAM stream, //)
                                            S32        stream_offset)
{
   ASISTREAM FAR *STR = (ASISTREAM FAR *) stream;

   //
   // Initialize output buffer
   //

   if (stream_offset != -2)
      {
      flush_stream(STR);
      }
   else
      {
      stream_offset=-1;
      }

   //
   // Set up to resume frame processing at specified seek position
   //
   // -1 causes current position to be maintained
   //

   STR->seek_param = stream_offset;

   //
   // Return success
   //

   return ASI_NOERR;
}

#define max(a,b)  (((a) > (b)) ? (a) : (b))

//############################################################################
//#                                                                          #
//# Retrieve an ASI stream property value by index                           #
//#                                                                          #
//############################################################################

static S32     AILCALL ASI_stream_property (HASISTREAM stream, //)
                                            HPROPERTY  property,
                                            void FAR * before_value,
                                            void const FAR* new_value,
                                            void FAR * after_value)
{
   ASISTREAM FAR *STR = (ASISTREAM FAR *) stream;

   switch ((PROPERTY) property)
      {
      //
      // Properties
      //

      case INPUT_BIT_RATE:
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->bit_rate;
          return 1;
        }
        break;

      case INPUT_SAMPLE_RATE:
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->sample_rate;
          return 1;
        }
        break;

      case INPUT_BITS:
        if (before_value) 
        {
          *(S32 FAR*)before_value = 1;
          return 1;
        }
        break;

      case INPUT_CHANNELS:
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->nch;
          return 1;
        }
        break;

      case OUTPUT_BIT_RATE:   
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->sample_rate * 16 * STR->nch;
          return 1;
        }
        break;

      case OUTPUT_SAMPLE_RATE: 
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->sample_rate;
          return 1;
        }
        break;

      case OUTPUT_BITS: 
        if (before_value) 
        {
          *(S32 FAR*)before_value = 16;
          return 1;
        }
        break;

      case OUTPUT_CHANNELS:
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->nch;
          return 1;
        }
        break;

      case OUTPUT_CHANNEL_MASK:
         if (before_value)
            {
            *(U32 FAR *) before_value = (STR->nch > 6) ? (1 << STR->nch)-1 : WDM_masks[STR->nch-1];
            return 1;
            }
         break;

      case OUTPUT_RESERVOIR: 
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->remaining_output_bytes;
          return 1;
        }
        break;

      case POSITION:   
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->current_offset;
          return 1;
        }
        break;

      case MIN_INPUT_BLOCK_SIZE: 
        if (before_value) 
        {
          *(S32 FAR*)before_value = OGG_PAGE_SIZE * 2;
          return 1;
        }
        break;

      case PERCENT_DONE:
        if (before_value) 
        {
         if ((STR->current_offset == 0) || (STR->total_size == 0))
         {
            *(F32 FAR*)before_value = 0.0f;
         }
         else
         {
            *(F32 FAR*)before_value = F32(STR->current_offset) * 100.0F / F32(STR->total_size);
         }
         return 1;
        }
        break;

      case REQUESTED_RATE:
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->requested_rate;
        }
        if (new_value)
        {
          STR->requested_rate  = *(S32 FAR*)new_value;
        }
        if (after_value) 
        {
          *(S32 FAR*)after_value = STR->requested_rate;
        }
        return 1;

      case REQUESTED_BITS:
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->requested_bits;
        }
        if (new_value)
        {
          STR->requested_bits  = *(S32 FAR*)new_value;
        }
        if (after_value) 
        {
          *(S32 FAR*)after_value = STR->requested_bits;
        }
        return 1;
  
      case REQUESTED_CHANS:
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->requested_chans;
        }
        if (new_value)
        {
          STR->requested_chans  = *(S32 FAR*)new_value;
        }
        if (after_value) 
        {
          *(S32 FAR*)after_value = STR->requested_chans;
        }
        return 1;

      case STREAM_SEEK_POS:
        if (before_value) 
        {
          *(S32 FAR*)before_value = STR->current_offset;
        }
        if (new_value)
        {
          STR->current_offset = STR->seek_param  = *(S32 FAR*)new_value;
        }
        if (after_value) 
        {
          *(S32 FAR*)after_value = STR->current_offset;
        }
        return 1;

      default:
         break;
      }

   return 0;
}

DXDEF S32 AILEXPORT RIB_MAIN_NAME(OggDec)( HPROVIDER provider_handle, U32 up_down )
{
   const RIB_INTERFACE_ENTRY ASI1[] =
      {
      REG_FN(PROVIDER_property),
      REG_PR("Name",                 PROVIDER_NAME,    (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_STRING)),
      REG_PR("Version",              PROVIDER_VERSION, (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_HEX)),
      REG_PR("Input file types",     IN_FTYPES,        (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_STRING)),
      };

   const RIB_INTERFACE_ENTRY ASI2[] =
      {
      REG_PR("Output file types",    OUT_FTYPES, (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_STRING)),
      REG_PR("Maximum frame size",   FRAME_SIZE, (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      };

   const RIB_INTERFACE_ENTRY ASI3[] =
      {
      REG_FN(ASI_startup),
      REG_FN(ASI_error),
      REG_FN(ASI_shutdown),
      };

   const RIB_INTERFACE_ENTRY ASISTR1[] =
      {
      REG_FN(ASI_stream_open),
      REG_FN(ASI_stream_process),
      REG_FN(ASI_stream_property),
      };

   const RIB_INTERFACE_ENTRY ASISTR2[] =
      {
      REG_FN(ASI_stream_seek),
      REG_FN(ASI_stream_close),
      REG_PR("Input bit rate",           INPUT_BIT_RATE,       (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      REG_PR("Input sample rate",        INPUT_SAMPLE_RATE,    (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      };

   const RIB_INTERFACE_ENTRY ASISTR3[] =
      {
      REG_PR("Input sample width",       INPUT_BITS,           (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      REG_PR("Input channels",           INPUT_CHANNELS,       (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      REG_PR("Output bit rate",          OUTPUT_BIT_RATE,      (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      REG_PR("Output sample rate",       OUTPUT_SAMPLE_RATE,   (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      };

   const RIB_INTERFACE_ENTRY ASISTR4[] =
      {
      REG_PR("Output sample width",      OUTPUT_BITS,          (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      REG_PR("Output channels",          OUTPUT_CHANNELS,      (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      REG_PR("Output reservoir",         OUTPUT_RESERVOIR,     (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      REG_PR("Position",                 POSITION,             (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      };

   const RIB_INTERFACE_ENTRY ASISTR5[] =
      {
      REG_PR("Output channel mask",      OUTPUT_CHANNEL_MASK,  (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      REG_PR("Percent done",             PERCENT_DONE,         (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_PERCENT)),
      REG_PR("Minimum input block size", MIN_INPUT_BLOCK_SIZE, (RIB_DATA_SUBTYPE) (RIB_READONLY|RIB_DEC)),
      };

   const RIB_INTERFACE_ENTRY ASISTR6[] =
      {
      REG_PR("Requested sample rate",    REQUESTED_RATE,       RIB_DEC),
      REG_PR("Requested bit width",      REQUESTED_BITS,       RIB_DEC),
      REG_PR("Requested # of channels",  REQUESTED_CHANS,      RIB_DEC),
      REG_PR("Stream seek position",     STREAM_SEEK_POS,      RIB_DEC),
      };

   if (up_down)
     {
         RIB_register(provider_handle, "ASI codec", ASI1);
         RIB_register(provider_handle, "ASI codec", ASI2);
         RIB_register(provider_handle, "ASI codec", ASI3);

         RIB_register(provider_handle, "ASI stream", ASISTR1);
         RIB_register(provider_handle, "ASI stream", ASISTR2);
         RIB_register(provider_handle, "ASI stream", ASISTR3);
         RIB_register(provider_handle, "ASI stream", ASISTR4);
         RIB_register(provider_handle, "ASI stream", ASISTR5);
         RIB_register(provider_handle, "ASI stream", ASISTR6);
      }
    else
      {
         RIB_unregister_all(provider_handle);
      }

   return TRUE;
}

