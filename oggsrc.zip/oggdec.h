//############################################################################
//##                                                                        ##
//##  Miles Sound System                                                    ##
//##                                                                        ##
//##  OGGDEC.H: Private header file for Ogg Vorbis ASI decoder              ##
//##                                                                        ##
//##  Version 1.00 of 25-Jan-06: Initial                                    ##
//##                                                                        ##
//##  Author: John Miles                                                    ##
//##                                                                        ##
//############################################################################
//##                                                                        ##
//##  Contact RAD Game Tools at 425-893-4300 for technical support.         ##
//##                                                                        ##
//############################################################################

#include "mss.h"
#include "imssapi.h"

#include "codec.h"

#ifdef IS_WINDOWS
#pragma pack(1)                   // Make SURE struct packing disabled!
#pragma warning(disable:4305)
#pragma warning(disable:4244)
#endif

#define OGG_PAGE_SIZE 4096        // Value from Ogg decoder example

#ifndef PI
#define PI 3.14159265358979f
#endif

struct ASISTREAM;

//
// Stream structure
//

typedef struct ASISTREAM
{
   //
   // Stream creation parameters
   //

   UINTa         user;
   VOIDFUNC *    fetch_CB;

   S32 total_size;

   //
   // Preferences (not currently supported)
   //

   S32 requested_rate;
   S32 requested_bits;
   S32 requested_chans;

   S32 bit_rate;
   S32 sample_rate;
   S32 nch;
   S32 bytes_per_sample;

   //
   // Other stream source parms
   //

   U32 current_offset;

   //
   // Ogg codec state
   //

   ogg_sync_state   oy;                               /* sync and verify incoming physical bitstream */
   ogg_stream_state os;                               /* take physical pages, weld into a logical
                                                      			  stream of packets */
   ogg_page         og;                               /* one Ogg bitstream page.  Vorbis packets are inside */
   ogg_packet       op;                               /* one raw packet of data for decode */

   vorbis_info      vi;                               /* struct that stores all the static vorbis bitstream
                                                        		  settings */
   vorbis_comment   vc;                               /* struct that stores all the bitstream user comments */
   vorbis_dsp_state vd;                               /* central working state for the packet->PCM decoder */
   vorbis_block     vb;                               /* local working space for packet->PCM decode */

   //
   // Miscellaneous stream decoder data
   //

   S32 seek_param;
   S32 remaining_output_bytes;

} ASISTREAM;

//
// Prototypes
//

static ASIRESULT AILEXPORT ASI_stream_close(ASISTREAM *stream);

#ifdef IS_WINDOWS
#pragma pack()
#endif
