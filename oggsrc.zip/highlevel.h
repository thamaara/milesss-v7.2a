/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS LIBRARY SOURCE IS     *
 * GOVERNED BY A BSD-STYLE SOURCE LICENSE INCLUDED WITH THIS SOURCE *
 * IN 'COPYING'. PLEASE READ THESE TERMS BEFORE DISTRIBUTING.       *
 *                                                                  *
 * THE OggVorbis SOURCE CODE IS (C) COPYRIGHT 1994-2002             *
 * by the XIPHOPHORUS Company http://www.xiph.org/                  *
 *                                                                  *
 ********************************************************************

 function: highlevel encoder setup struct seperated out for vorbisenc clarity
 last mod: $Id: highlevel.h 7187 2004-07-20 07:24:27Z xiphmont $

 ********************************************************************/

typedef struct highlevel_byblocktype {
  DOUBLE tone_mask_setting;
  DOUBLE tone_peaklimit_setting;
  DOUBLE noise_bias_setting;
  DOUBLE noise_compand_setting;
} highlevel_byblocktype;
  
typedef struct highlevel_encode_setup {
  void *setup;
  int   set_in_stone;

  DOUBLE base_setting;
  DOUBLE long_setting;
  DOUBLE short_setting;
  DOUBLE impulse_noisetune;

  int    managed;
  S32    bitrate_min;
  S32    bitrate_av;
  DOUBLE bitrate_av_damp;
  S32    bitrate_max;
  S32    bitrate_reservoir;
  DOUBLE bitrate_reservoir_bias;
  
  int impulse_block_p;
  int noise_normalize_p;

  DOUBLE stereo_point_setting;
  DOUBLE lowpass_kHz;

  DOUBLE ath_floating_dB;
  DOUBLE ath_absolute_dB;

  DOUBLE amplitude_track_dBpersec;
  DOUBLE trigger_setting;
  
  highlevel_byblocktype block[4]; /* padding, impulse, transition, S32  */

} highlevel_encode_setup;

